public class menu {

    public void PrintMenu(){
        System.out.println("Redirecting to the Main Menu....");
        System.out.println(" ");
        System.out.println("Welcome to Down Town Hotel And Casino");
        System.out.println("=====================================");
        System.out.println(" ");
        System.out.println(" ");


        System.out.println(" 1. Vew Available Rooms ");
        System.out.println(" 2. Allocate a Room for Guest ");
        System.out.println(" 3. Change/ Delete Room Allocation for a Guest ");
        System.out.println(" 4. Check - in to a Room & Checkout from a Room ");
        System.out.println(" 5. Exit ");
        System.out.println(" ");
        System.out.println("=====================================");
        System.out.println(" ");
    }
}
