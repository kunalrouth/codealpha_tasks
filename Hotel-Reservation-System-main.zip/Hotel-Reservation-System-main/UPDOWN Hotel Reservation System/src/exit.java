public class exit {

    public void ExitSys(){
        System.out.println(" Have A Nice Day....");
        System.out.println(" ");
        System.out.println(" EXIT FROM SYSTEM ....");
        System.exit(0);
    }
}
